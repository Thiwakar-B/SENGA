package com.example.senga;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity6Bmi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity6_bmi);
    }
}